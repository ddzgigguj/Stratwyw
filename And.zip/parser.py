# ============================================
# Парсер сообщений из Telegram канала
# ============================================

import re
from datetime import datetime
from typing import Dict, Optional, List
from dataclasses import dataclass


@dataclass
class MatchData:
    """Данные матча из сообщения"""
    match_time: str
    match_date: str
    match_id: str
    league: str
    player1: str  # Английское имя
    player2: str  # Английское имя
    p1_name_ru: str  # Русское имя
    p2_name_ru: str  # Русское имя
    p1_match_coef: float
    p2_match_coef: float
    p1_round_coef: float
    p2_round_coef: float
    fbr_f: float  # Fatality coef
    fbr_b: float  # Brutality coef
    fbr_r: float  # No finisher coef
    fw: float  # FW value
    atv: float  # Average time per round
    time_stats: Dict[str, Dict]
    raw_message: str
    parsed_at: datetime = None
    
    def __post_init__(self):
        if self.parsed_at is None:
            self.parsed_at = datetime.now()


@dataclass
class RoundResult:
    """Результат одного раунда"""
    round_num: int
    winner: str  # P1 или P2
    finish_type: str  # F, B, или R
    duration: int  # секунды
    is_tm: bool  # ТМ или ТБ


@dataclass
class MatchResult:
    """Итоговый результат матча"""
    match_id: str
    total_rounds: int
    p1_wins: int
    p2_wins: int
    rounds: List[RoundResult]
    final_finish: str
    winner: str


class MessageParser:
    """Парсер сообщений канала MK"""
    
    def __init__(self):
        self.match_id_pattern = re.compile(r'#(N\d+)', re.IGNORECASE)
        self.round_result_pattern = re.compile(
            r'(\d+)\.\s*(P1|P2)--([FBR])--(\d+)(?:\s+(TM|TB|TMM|TBB))?',
            re.IGNORECASE
        )
    
    def parse_match_message(self, message: str) -> Optional[MatchData]:
        """Парсит сообщение о предстоящем матче"""
        try:
            lines = [line.strip() for line in message.strip().split('\n') if line.strip()]
            if not lines:
                return None
            
            # Парсим время и дату
            header = lines[0]
            time_match = re.search(r'(\d{2}:\d{2})\s+(\d{2}-\d{2}-\d{4})', header)
            if not time_match:
                return None
            
            match_time = time_match.group(1)
            match_date = time_match.group(2)
            
            # Парсим ID матча и лигу
            match_id_match = self.match_id_pattern.search(header)
            league_match = re.search(r'#(L\d+)', header)
            match_id = match_id_match.group(1) if match_id_match else "Unknown"
            league = league_match.group(1) if league_match else "L0"
            
            # Имена персонажей
            p1_name = ""
            p2_name = ""
            p1_name_ru = ""
            p2_name_ru = ""
            
            # Ищем английские имена (Kitana - Ferra & Torr)
            for line in lines:
                if ' - ' in line and 'P1' not in line and 'FBR' not in line and 'TimeStat' not in line and 'atv' not in line:
                    parts = line.split(' - ')
                    if len(parts) == 2:
                        p1_name = parts[0].strip()
                        p2_name = parts[1].strip()
                        break
            
            # Ищем русские имена из хештегов
            for line in lines:
                # Ищем хештеги с именами (исключаем технические)
                hashtag_match = re.findall(r'#(?!N\d+|L\d+|FW|T\d+|m\d+|s\d+|b\d+|t\d+v\d+)([^\s#]+)', line)
                if len(hashtag_match) >= 2:
                    p1_name_ru = hashtag_match[0]
                    p2_name_ru = hashtag_match[1]
                    break
            
            # Коэффициенты
            p1_match_coef = 0.0
            p2_match_coef = 0.0
            p1_round_coef = 0.0
            p2_round_coef = 0.0
            f_fat = 0.0
            f_brut = 0.0
            f_none = 0.0
            fw = 0.0
            atv = 0.0
            
            for line in lines:
                # P1m|P2m - коэффициенты на матч
                match_coef = re.search(r'P1m\|P2m\s*-\s*([\d.]+)\|([\d.]+)', line, re.IGNORECASE)
                if match_coef:
                    p1_match_coef = float(match_coef.group(1))
                    p2_match_coef = float(match_coef.group(2))
                
                # P1/P2 - коэффициенты на раунд
                round_coef = re.search(r'P1/P2\s*-\s*([\d.]+)/([\d.]+)', line, re.IGNORECASE)
                if round_coef:
                    p1_round_coef = float(round_coef.group(1))
                    p2_round_coef = float(round_coef.group(2))
                
                # FBR - коэффициенты на добивания
                fbr_match = re.search(r'FBR\s*-\s*([\d.]+)\s*\|\s*([\d.]+)\s*\|\s*([\d.]+)', line, re.IGNORECASE)
                if fbr_match:
                    f_fat = float(fbr_match.group(1))
                    f_brut = float(fbr_match.group(2))
                    f_none = float(fbr_match.group(3))
                
                # FW value
                fw_match = re.search(r'#FW\s*-\s*([\d.]+)', line, re.IGNORECASE)
                if fw_match:
                    fw = float(fw_match.group(1))
                
                # ATV - среднее время раунда
                atv_match = re.search(r'atv\s*:\s*([\d.]+)', line, re.IGNORECASE)
                if atv_match:
                    atv = float(atv_match.group(1))
            
            # TimeStat данные
            time_stats = {}
            for line in lines:
                # Парсим строки типа: 16.5 (1.22 - 4.23)   #m16
                ts_match = re.search(r'(\d{2}\.5)\s*\(([\d.]+)\s*-\s*([\d.]+)\)\s*#(\w+)', line)
                if ts_match:
                    threshold = ts_match.group(1)
                    over_coef = float(ts_match.group(2))
                    under_coef = float(ts_match.group(3))
                    tag = ts_match.group(4)
                    time_stats[tag] = {
                        "threshold": threshold,
                        "over": over_coef,
                        "under": under_coef
                    }
            
            return MatchData(
                match_time=match_time,
                match_date=match_date,
                match_id=match_id,
                league=league,
                player1=p1_name,
                player2=p2_name,
                p1_name_ru=p1_name_ru,
                p2_name_ru=p2_name_ru,
                p1_match_coef=p1_match_coef,
                p2_match_coef=p2_match_coef,
                p1_round_coef=p1_round_coef,
                p2_round_coef=p2_round_coef,
                fbr_f=f_fat,
                fbr_b=f_brut,
                fbr_r=f_none,
                fw=fw,
                atv=atv,
                time_stats=time_stats,
                raw_message=message
            )
        except Exception as e:
            print(f"Ошибка парсинга сообщения: {e}")
            return None
    
    def parse_result_message(self, message: str) -> Optional[MatchResult]:
        """Парсит сообщение с результатами раундов"""
        try:
            lines = message.strip().split('\n')
            
            # Ищем ID матча
            match_id = None
            id_match = self.match_id_pattern.search(message)
            if id_match:
                match_id = id_match.group(1)
            
            p1_wins = 0
            p2_wins = 0
            rounds = []
            
            for line in lines:
                # Парсим счет (5:4)
                score_match = re.match(r'(\d+):(\d+)', line.strip())
                if score_match:
                    p1_wins = int(score_match.group(1))
                    p2_wins = int(score_match.group(2))
                    continue
                
                # Парсим раунды (1. P2--F--36)
                round_match = self.round_result_pattern.search(line)
                if round_match:
                    round_num = int(round_match.group(1))
                    winner = round_match.group(2)
                    finish_type = round_match.group(3)
                    duration = int(round_match.group(4))
                    tm_tb_val = round_match.group(5) or "TM"
                    is_tm = tm_tb_val.upper().startswith("TM")
                    
                    rounds.append(RoundResult(
                        round_num=round_num,
                        winner=winner,
                        finish_type=finish_type,
                        duration=duration,
                        is_tm=is_tm
                    ))
            
            if not rounds:
                return None
            
            total_rounds = len(rounds)
            final_round = rounds[-1]
            final_finish = final_round.finish_type
            winner = "P1" if p1_wins > p2_wins else "P2"
            
            return MatchResult(
                match_id=match_id or "Unknown",
                total_rounds=total_rounds,
                p1_wins=p1_wins,
                p2_wins=p2_wins,
                rounds=rounds,
                final_finish=final_finish,
                winner=winner
            )
        except Exception as e:
            print(f"Ошибка парсинга результата: {e}")
            return None
