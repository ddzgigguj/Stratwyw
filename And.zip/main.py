# ============================================
# Главный файл Telegram бота Mortal Kombat
# ============================================

import asyncio
import logging
import signal
import sys
import re
from datetime import datetime, timedelta
from typing import Dict, Optional

from telethon import TelegramClient, events
from telethon.tl.types import PeerChannel
from telegram import Bot
from telegram.constants import ParseMode

from config import (
    TELEGRAM_API_ID,
    TELEGRAM_API_HASH,
    PHONE_NUMBER,
    BOT_TOKEN,
    SOURCE_CHANNEL,
    TARGET_GROUP_ID,
    ADMIN_USER_ID,
    CHECK_INTERVAL,
    DAILY_REPORT_HOUR,
    DAILY_REPORT_MINUTE
)
from parser import MessageParser, MatchData, RoundResult, MatchResult
from strategy import MKStrategy, BetTracker
from database import StatsManager, MatchRecord

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('bot.log', encoding='utf-8'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)


class MKTelegramBot:
    """Telegram бот для стратегии Mortal Kombat"""
    
    def __init__(self):
        # Telethon клиент для мониторинга канала
        self.client = TelegramClient(
            'mk_session',
            TELEGRAM_API_ID,
            TELEGRAM_API_HASH
        )
        
        # python-telegram-bot для отправки сообщений
        self.bot = Bot(token=BOT_TOKEN)
        
        # Парсер сообщений
        self.parser = MessageParser()
        
        # Стратегия анализа
        self.strategy = MKStrategy()
        
        # Трекер ставок
        self.bet_tracker = BetTracker()
        
        # Менеджер статистики
        self.stats = StatsManager()
        
        # Активные матчи
        self.active_matches: Dict[str, MatchData] = {}
        
        # Флаг работы бота
        self.running = False
        
        # ID канала
        self.source_channel_id = None
    
    async def start(self):
        """Запускает бота"""
        logger.info("Запуск бота Mortal Kombat Strategy...")
        
        # Подключаемся к Telegram
        await self.client.start(phone=PHONE_NUMBER)
        logger.info("Подключение к Telegram установлено")
        
        # Получаем ID канала
        try:
            channel = await self.client.get_entity(SOURCE_CHANNEL)
            self.source_channel_id = channel.id
            logger.info(f"Канал {SOURCE_CHANNEL} найден, ID: {self.source_channel_id}")
        except Exception as e:
            logger.error(f"Ошибка получения канала: {e}")
            return
        
        # Регистрируем обработчики
        self._register_handlers()
        
        # Запускаем фоновые задачи
        self.running = True
        asyncio.create_task(self._daily_report_task())
        asyncio.create_task(self._cleanup_old_matches_task())
        
        # Уведомление админу
        await self._notify_admin("✅ Бот запущен и мониторит канал @" + SOURCE_CHANNEL)
        
        logger.info("Бот успешно запущен!")
        
        # Держим бота запущенным
        while self.running:
            await asyncio.sleep(1)
    
    def _register_handlers(self):
        """Регистрирует обработчики событий"""
        
        @self.client.on(events.NewMessage(chats=self.source_channel_id))
        async def handle_new_message(event):
            """Обработка новых сообщений"""
            await self._process_channel_message(event.message)
        
        @self.client.on(events.MessageEdited(chats=self.source_channel_id))
        async def handle_edited_message(event):
            """Обработка отредактированных сообщений"""
            await self._process_channel_message(event.message)
    
    async def _process_channel_message(self, message):
        """Обрабатывает сообщения из канала"""
        try:
            message_text = message.message
            if not message_text:
                return
            
            # Проверяем, является ли сообщение результатом матча
            result_data = self.parser.parse_result_message(message_text)
            if result_data:
                logger.info(f"Получен результат матча: {result_data.match_id}")
                await self._process_result(result_data, message_text)
                return
            
            # Проверяем, является ли сообщение данными о матче
            match_data = self.parser.parse_match_message(message_text)
            if match_data:
                # Если матч уже в активных, пропускаем
                if match_data.match_id in self.active_matches:
                    logger.debug(f"Матч {match_data.match_id} уже в активных")
                    return
                
                logger.info(f"Получены данные о матче: {match_data.match_id}")
                await self._process_match(match_data)
                return
        
        except Exception as e:
            logger.error(f"Ошибка обработки сообщения: {e}")
    
    async def _process_match(self, match: MatchData):
        """Обрабатывает данные о матче"""
        # Анализируем матч
        analysis = self.strategy.analyze(match)
        
        # Сохраняем матч
        self.active_matches[match.match_id] = match
        
        # Создаем запись
        match_record = MatchRecord(
            match_id=match.match_id,
            match_time=match.match_time,
            match_date=match.match_date,
            player1=match.player1,
            player2=match.player2,
            p1_coef=match.p1_match_coef,
            p2_coef=match.p2_match_coef,
            fat_coef=match.fbr_f,
            atv=match.atv,
            analysis_confidence=analysis.confidence,
            should_bet=analysis.should_bet,
            bet_on=analysis.bet_type if analysis.should_bet else None,
            result="pending"
        )
        self.stats.save_active_match(match_record)
        
        # Если ставка рекомендуется
        if analysis.should_bet:
            self.bet_tracker.add_bet(match.match_id, {
                "bet_type": analysis.bet_type,
                "target_rounds": analysis.target_rounds,
                "round_range": analysis.round_range
            })
            
            # Отправляем сообщение
            message = self._format_analysis_message(match, analysis)
            sent_msg = await self._send_to_group(message)
            
            # Сохраняем ID сообщения
            if sent_msg:
                self.bet_tracker.set_message_id(match.match_id, sent_msg.message_id)
        else:
            skip_reason = analysis.skip_reason if analysis.skip_reason else "недостаточно уверенности"
            logger.info(f"Матч {match.match_id} пропущен ({skip_reason})")
        
        logger.info(f"Матч {match.match_id} обработан, ставка: {analysis.should_bet}")
    
    async def _process_result(self, result: MatchResult, message_text: str):
        """Обрабатывает результат матча"""
        match_id = None
        
        # 1. Ищем по ID
        if result.match_id and result.match_id != "Unknown":
            if result.match_id in self.active_matches:
                match_id = result.match_id
        
        # 2. Ищем по времени и именам
        if not match_id:
            for mid, match in self.active_matches.items():
                if self._is_same_match(match, message_text):
                    match_id = mid
                    break
        
        if not match_id:
            return
        
        match = self.active_matches.get(match_id)
        bet = self.bet_tracker.get_bet_status(match_id)
        
        # Если ставки не было
        if not bet:
            return
        
        # Обновляем результаты раундов
        for round_result in result.rounds:
            emoji = self.bet_tracker.update_round_result(match_id, round_result)
            
            if emoji:
                # Ставка завершена
                updated_bet = self.bet_tracker.get_bet_status(match_id)
                status = updated_bet.get("status")
                message_id = updated_bet.get("message_id")
                
                if status == "won":
                    result_round = round_result.round_num
                    await self._edit_result_message(match, emoji, result_round, "won", message_id)
                    self.stats.update_match_result(match_id, "won", result_round, emoji)
                elif status == "lost":
                    await self._edit_result_message(match, "❌", None, "lost", message_id)
                    self.stats.update_match_result(match_id, "lost", None, "❌")
                
                # Удаляем из активных
                if match_id in self.active_matches:
                    del self.active_matches[match_id]
                break
    
    def _is_same_match(self, match: MatchData, result_text: str) -> bool:
        """Проверяет, относится ли результат к матчу"""
        result_lower = result_text.lower()
        
        # Проверка по времени
        if match.match_time in result_text:
            p1_names = [match.player1.lower(), match.p1_name_ru.lower()]
            p2_names = [match.player2.lower(), match.p2_name_ru.lower()]
            
            p1_found = any(name and len(name) > 2 and name in result_lower for name in p1_names)
            p2_found = any(name and len(name) > 2 and name in result_lower for name in p2_names)
            
            if p1_found or p2_found:
                return True
        
        # Проверка по именам
        p1_names = [match.player1.lower(), match.p1_name_ru.lower()]
        p2_names = [match.player2.lower(), match.p2_name_ru.lower()]
        
        def clean(s): return re.sub(r'[\s\-_]+', '', s).lower()
        
        p1_found = any(name and len(name) > 2 and (name in result_lower or clean(name) in clean(result_text)) for name in p1_names)
        p2_found = any(name and len(name) > 2 and (name in result_lower or clean(name) in clean(result_text)) for name in p2_names)
        
        return p1_found and p2_found
    
    def _format_analysis_message(self, match: MatchData, analysis) -> str:
        """Форматирует сообщение с анализом"""
        bet_name = "ФАТАЛИТИ" if analysis.bet_type == "F" else "БРУТАЛИТИ"
        
        message = (
            f"<b>{match.match_time} {match.match_date}</b>\n"
            f"#{match.match_id}\n"
            f"#{match.p1_name_ru}{match.p2_name_ru}\n"
            f"<code>{match.p1_match_coef} | {match.p2_match_coef}</code>\n"
            f"FBR: {match.fbr_f} | {match.fbr_b} | {match.fbr_r}\n"
            f"ATV: {match.atv}\n"
            f"F коридора: {analysis.time_f_prob:.1f}%\n"
            f"Фатовость пары: {analysis.char_f_prob:.1f}%\n\n"
            f"<b>Ставим на {bet_name}</b>\n"
            f"Раунды: {analysis.round_range}"
        )
        
        return message
    
    async def _edit_result_message(self, match: MatchData, emoji: str, result_round: int, status: str, message_id: int):
        """Редактирует сообщение с результатом"""
        if not message_id:
            await self._send_result_message_fallback(match, emoji, result_round, status)
            return
        
        bet = self.bet_tracker.get_bet_status(match.match_id)
        bet_type = bet.get("bet_type", "F")
        bet_name = "ФАТАЛИТИ" if bet_type == "F" else "БРУТАЛИТИ"
        round_range = bet.get("round_range", "1-3")
        
        message = (
            f"<b>{match.match_time} {match.match_date}</b>\n"
            f"#{match.match_id}\n"
            f"#{match.p1_name_ru}{match.p2_name_ru}\n"
            f"<code>{match.p1_match_coef} | {match.p2_match_coef}</code>\n"
            f"FBR: {match.fbr_f} | {match.fbr_b} | {match.fbr_r}\n\n"
            f"Ставка на {bet_name} (раунды {round_range})\n"
        )
        
        if status == "won":
            message += f"Результат: <b>{emoji} ПЛЮС (Раунд {result_round})</b>"
        else:
            message += f"Результат: <b>❌ МИНУС</b>"
        
        try:
            await self.bot.edit_message_text(
                chat_id=TARGET_GROUP_ID,
                message_id=message_id,
                text=message,
                parse_mode=ParseMode.HTML
            )
            logger.info(f"Сообщение {message_id} отредактировано: {status}")
        except Exception as e:
            logger.error(f"Ошибка редактирования: {e}")
            await self._send_result_message_fallback(match, emoji, result_round, status)
    
    async def _send_result_message_fallback(self, match: MatchData, emoji: str, result_round: int, status: str):
        """Запасной метод отправки результата"""
        bet = self.bet_tracker.get_bet_status(match.match_id)
        bet_type = bet.get("bet_type", "F")
        bet_name = "ФАТАЛИТИ" if bet_type == "F" else "БРУТАЛИТИ"
        round_range = bet.get("round_range", "1-3")
        
        message = (
            f"<b>{match.match_time} {match.match_date}</b>\n"
            f"#{match.match_id}\n"
            f"Ставка на {bet_name} (раунды {round_range})\n\n"
        )
        
        if status == "won":
            message += f"Результат: <b>{emoji} ПЛЮС (Раунд {result_round})</b>"
        else:
            message += f"Результат: <b>❌ МИНУС</b>"
        
        await self._send_to_group(message)
    
    async def _send_to_group(self, message: str):
        """Отправляет сообщение в группу"""
        try:
            return await self.bot.send_message(
                chat_id=TARGET_GROUP_ID,
                text=message,
                parse_mode=ParseMode.HTML
            )
        except Exception as e:
            logger.error(f"Ошибка отправки: {e}")
            return None
    
    async def _notify_admin(self, message: str):
        """Отправляет уведомление админу"""
        try:
            await self.bot.send_message(
                chat_id=ADMIN_USER_ID,
                text=message,
                parse_mode=ParseMode.HTML
            )
        except Exception as e:
            logger.error(f"Ошибка уведомления: {e}")
    
    async def _daily_report_task(self):
        """Ежедневный отчет"""
        while self.running:
            try:
                now = datetime.now()
                if now.hour == DAILY_REPORT_HOUR and now.minute == DAILY_REPORT_MINUTE:
                    stats = self.stats.get_daily_stats()
                    report = self.stats.format_daily_report()
                    await self._send_to_group(report)
                    await asyncio.sleep(60)
                await asyncio.sleep(30)
            except Exception as e:
                logger.error(f"Ошибка отчета: {e}")
                await asyncio.sleep(60)
    
    async def _cleanup_old_matches_task(self):
        """Очистка старых матчей"""
        while self.running:
            try:
                now = datetime.now()
                to_delete = []
                for mid, match in self.active_matches.items():
                    if match.parsed_at and (now - match.parsed_at).total_seconds() > 7200:
                        to_delete.append(mid)
                
                for mid in to_delete:
                    del self.active_matches[mid]
                
                await asyncio.sleep(600)
            except Exception as e:
                logger.error(f"Ошибка очистки: {e}")
                await asyncio.sleep(60)


if __name__ == "__main__":
    bot = MKTelegramBot()
    loop = asyncio.get_event_loop()
    try:
        loop.run_until_complete(bot.start())
    except KeyboardInterrupt:
        pass
